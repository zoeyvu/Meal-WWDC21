/*:
 
 ![Meal](header.png)
 
 # It is meal time now!👋
 
 This playground aims to give a foundational understanding of nutrition to children and teenager. Thus, encouraged them to have a healthy combination of food in every meal.
 
 
 ## Your Online Nutritionist Friend 🤓🍔
 
 As a gentle introduction about nutrition, this playground introduce a friend that knows a lot about nutrition to children. From my observation, children is more engaged in game-like activities and thus remember information introduced in the game more.
 

 ---

## Credits and Thanks 🙏
 
  - [Canada Food Guide](https://food-guide.canada.ca/en/) for creative and informative nutrition information
  - [Alberta Health Services Nutrition Lesson](https://www.albertahealthservices.ca/nutrition/Page2918.aspx) for interesting ideas to introduce nutrition for kids
  - [Developing Apps for iOS Course](https://cs193p.sites.stanford.edu) for ideas about implementation
 ---
*/
import PlaygroundSupport
PlaygroundPage.current.liveView = PlaygroundView.introductionView1
