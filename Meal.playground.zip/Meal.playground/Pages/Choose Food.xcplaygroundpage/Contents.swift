/*:
 
 # It is now time to choose your food 😋
 
 This page aim to give a brief evaluation of chosen food for a meal. It allows drag-drop food from the top to the plate area in the middle, and evaluate the food after hitting the "Check" button. Have fun and test out your favorite meal!
 
 * Callout(Tip💡):
 If you find trouble with drag-and-drop, click the food emoji, hold for 0.1s, drag into the plate area, find a spacy area to drop your food, the food should have a green + sign on the top left now, then drop it.
 
 ![Example](example.gif)
 
 ---
 
 ## Choose Food From Every Type Of Nutrients 🥐 🥩 🥛 🌿
 
 Choosing at least one food from each type of nutrients ensure you have all the energy and vitamin you need for a healthy life. Eating junk food can be healthy if you eat in a small amount and pair it with protein and vegetables!
 
 * Callout(Tip💡):
 See more food by swiping left and right on the food bar.
 
 * Callout(Tip💡):
 Change to other type of nutrients by clicking plus + and minus - button on the top left corner.
 
 ---
 
 ## Enjoy and Have Fun 🥳
 
 Nice to see you today. I hope this help you to eat well and keep your awesome body in its best shape!
 
 * Hint:
 Try 🍚 with 🍤 and 🥒. Yummy combination.
 
*/
import PlaygroundSupport
PlaygroundPage.current.liveView = PlaygroundView.chooseFoodView

