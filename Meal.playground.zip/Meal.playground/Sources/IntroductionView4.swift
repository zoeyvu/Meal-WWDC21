import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct IntroductionView4: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            Image(uiImage: #imageLiteral(resourceName: "4.png"))
                .frame(height: 450)
            Text("Don’t worry, I will tell you the secret of having a healthy diet: every meal, you should eat a little bit of each type of nutrients ✨                                                                  Eat nutrients = Good nutrition ✅")
                .textStyle(size: 15, color: Color(.darkGray), weight: .regular)
                .padding()
                .frame(width: 370, height: 130)
                .background(Color.white)
                .foregroundColor(.black)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray, lineWidth: 3)
                )
            Spacer()
                .frame(height: 15)
            Button(action: {
                AudioServicesPlaySystemSound(1103)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView6
                }
            }, label: {
                Text("Tap to continue")
                    .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
            })
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        .onTapGesture {
            AudioServicesPlaySystemSound(1103)
            // Go to next page
            DispatchQueue.main.asyncAfter(deadline: .now()) {
                PlaygroundPage.current.liveView = PlaygroundView.introductionView6
            }
        }
    }
}
