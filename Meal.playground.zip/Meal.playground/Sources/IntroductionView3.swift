import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct IntroductionView3: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            Image(uiImage: #imageLiteral(resourceName: "3.png"))
                .frame(height: 450)
            Text("Yes, your body is made from what you eat. If you don’t eat enough of what your body needs, then your body would become very sick 🤒")
                .textStyle(size: 15, color: Color(.darkGray), weight: .regular)
                .padding()
                .frame(width: 370, height: 130)
                .background(Color.white)
                .foregroundColor(.black)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray, lineWidth: 3)
                )
            Spacer()
                .frame(height: 15)
            Button(action: {
                AudioServicesPlaySystemSound(1325)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView4
                }
            }, label: {
                Text("Tap to continue")
                    .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
            })
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        .onTapGesture {
            AudioServicesPlaySystemSound(1325)
            // Go to next page
            DispatchQueue.main.asyncAfter(deadline: .now()) {
                PlaygroundPage.current.liveView = PlaygroundView.introductionView4
            }
        }
    }
}
