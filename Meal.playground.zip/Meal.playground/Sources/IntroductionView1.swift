import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct IntroductionView1: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            Text("🍽")
                .textStyle(size: 80, color: Color(.darkGray) , weight: .bold)
            
            Text("Meal")
                .textStyle(size: 40, color: Color(.darkGray) , weight: .bold)
            
            Text("WWDC21")
                .textStyle(size: 20, color: Color(#colorLiteral(red: 0.26514732837677, green: 0.26514732837677, blue: 0.26514732837677, alpha: 1.0)), weight: .medium)
            
            Spacer()
                .frame(height: 20)
            Button(action: {
                AudioServicesPlaySystemSound(1322)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView2
                }
            }, label: {
                Text("Tap to continue")
                    .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
            })
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        .onTapGesture {
            AudioServicesPlaySystemSound(1322)
            // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView2
                    
                }
        }
    }
}
