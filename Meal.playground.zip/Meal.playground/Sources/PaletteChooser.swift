import SwiftUI

public struct PaletteChooser: View {
    @ObservedObject var document: ChooseFoodDocument
    
    @Binding var chosenPalette: String
    
    public var body: some View {
        HStack {
            Text(self.document.paletteNames[self.chosenPalette] ?? "                                               ")
                .textStyle(size: 40, color: Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)), weight: .semibold)
                    .frame(width: 270)
                    .alignmentGuide(HorizontalAlignment.leading, computeValue: { _ in  0})
                Stepper(
                    onIncrement: { self.chosenPalette = self.document.palette(after: self.chosenPalette ) },
                    onDecrement: { self.chosenPalette = self.document.palette(before: self.chosenPalette ) },
                    label: {
                        EmptyView()
                    })
                    .frame(width: 100, height: 35)
                    .offset(x: -4)
                    .background(Color(#colorLiteral(red: 0.9686274529, green: 0.7116591147, blue: 0.4154293284, alpha: 0.8094760609)))
                    .foregroundColor(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .cornerRadius(8)
        }
        .fixedSize(horizontal: true, vertical: false)
    }
}

