import SwiftUI
import PlaygroundSupport

public struct IntroductionView9: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            Image(uiImage: #imageLiteral(resourceName: "9.png"))
                .frame(height: 450)

            
            Text("Now that you know the secret of nutrition, it is time to practice. Let's go to Choose Food page on Playground's left tab bar 👈")
                .textStyle(size: 15, color: Color(.darkGray), weight: .regular)
                .padding()
                .frame(width: 370, height: 130)
                .background(Color.white)
                .foregroundColor(Color.black)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray, lineWidth: 3)
                )
            Spacer()
                .frame(height: 15)
            Text("")
                .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        
    }
}


