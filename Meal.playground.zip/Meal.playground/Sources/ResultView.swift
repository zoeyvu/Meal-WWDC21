import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct ResultView: View {
    
    // MARK: - Properties
    @Binding var nutrition: Array<Int>
    var isHealthy: Bool {
        return !(isMuchCarbs() || isMuchProtein() || isMuchFat() || isLittleCarbs() || isLittleProtein() || isLittleFat() || isLittleGreen())
    }
    
    // MARK: - Content View
    public var body: some View {
        ScrollView(.vertical, showsIndicators: true)  {
            Spacer()
                .frame(height: 30)
            Text("Result:")
                .textStyle(size: 50, color: Color(.darkGray), weight: .bold)
            Spacer()
                .frame(height: 10)
            VStack (alignment: .center) {
                VStack {
                    Spacer()
                        .frame(height: 20)
                    if isHealthy {
                        Text("🤩")
                            .textStyle(size: 200, color: Color(.darkGray), weight: .regular)
                        Text("Your meal is ideal!")
                            .textStyle(size: 25, color: Color(.darkGray), weight: .bold)
                        Text("Congratulation, you know how to develop a healthy full of nutrient.")
                            .textStyle(size: 10, color: Color(.darkGray), weight: .medium)
                        Spacer()
                            .frame(height: 40)
                    } else {
                        Text("😵")
                            .textStyle(size: 200, color: Color(.darkGray), weight: .regular)
                        Text("Your meal should be improved!")
                            .textStyle(size: 23, color: Color(.darkGray), weight: .bold)
                            .padding(.horizontal)
                        Text("Read information below to improve your choice of food")
                            .textStyle(size: 10, color: Color(.darkGray), weight: .medium)
                        Spacer()
                            .frame(height: 80)
                    }
                }
                .background(Color(#colorLiteral(red: 0.9686274529, green: 0.7116591147, blue: 0.4154293284, alpha: 0.3058709384)))
                .cornerRadius(20)
                
                if !isHealthy {
                    Spacer()
                        .frame(height: 70)
                }
                
                VStack {
                    if !isHealthy {
                        Text("Problems Overview:")
                            .textStyle(size: 30, color: Color(.darkGray), weight: .bold)
                    }
                    if isMuchCarbs() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Too much carbs")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("Consider eating less bread, grains, rice, cake. Eating too much carbonhydte and not enough other nutrition for a long period will make you crave for food and get chills even in hot weather.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("🥶")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isMuchProtein() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Too much protein")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("Consuming too much protein can cause diarrhea, kidney damage, heart disease, weight gain, and bad breath. It can also increase the chances of getting cancer. Consider eating less meat and legumes.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("😱")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isMuchFat() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Too much fat")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("Consuming too much fat puts extreme stress on your organs and can lead to heart, artery, liver, and/or kidney problems. Consider eating less creamy and oily foods.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("😰")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isLittleCarbs() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Not enough carbs")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("A lack of carbohydrates can affect your productivity by causing anxiety, shaky muscles, dizziness, mental fatigue, nausea, and headaches. Consider eating more grain products like bread, rice, and noodles.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("🥴")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isLittleProtein() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Not enough protein")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("Proteins are the building blocks of your body. Not having enough protein can cause hair loss, flaky skin, weak bones, and slower growth in height. You should eat more protein.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("😱")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isLittleFat() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Not enough fat")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("Fats help absorb vitamins, support cell growth, and your eyes and brain functions. Consider adding more healthy fats such as fish, seeds, and nuts into your diet.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("😞")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                    if isLittleGreen() {
                        Spacer()
                            .frame(height: 25)
                        HStack {
                            VStack (alignment: .leading){
                                Text("Too little veggies")
                                    .textStyle(size: 20, color: Color(.darkGray), weight: .bold)
                                Text("A lack of vitamins can weaken your immune system, decrease memory, and cause muscle cramps. Besides, not eating enough vegetables will cause VERY bad toilet trips.")
                                    .textStyle(size: 10, color: Color(.darkGray), weight: .bold)
                                    .frame(width: 220, height: 70)
                            }
                            Spacer()
                            Text("🤧")
                                .textStyle(size: 70, color: Color(.darkGray), weight: .regular)
                        }
                        Spacer()
                            .frame(height:20)
                    }
                }
                .padding()
                .cornerRadius(20)

                if !isHealthy {
                    Spacer()
                        .frame(height: 100)
                }
                
                
                Button(action: {
                    AudioServicesPlaySystemSound(1334)
                    // Go to next page
                    DispatchQueue.main.asyncAfter(deadline: .now()) {
                        PlaygroundPage.current.liveView = PlaygroundView.chooseFoodView
                    }
                }, label: {
                    Text("Try Again")
                        .textStyle(size: 35, color: Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), weight: .bold)
                        .frame(width: 380, height: 60)
                        .background(Color(#colorLiteral(red: 0.9686274529, green: 0.7116591147, blue: 0.4154293284, alpha: 1)))
                        .cornerRadius(10)
                        .padding(.vertical)
                })
                
                Spacer()
                    .frame(height: 30)
            }
            .padding()
            
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))

            
    }
    
    private func getTotal() -> Double {
        return Double(nutrition[0] + nutrition[1] + nutrition[2])
    }
    
    private func getPercentCarbs() -> Double {
        let total = getTotal()
        let carbs = Double(nutrition[0])
        if carbs == 0 { return 0 }
        return carbs/total
    }
    
    private func getPercentProtein() -> Double {
        let total = getTotal()
        let protein = Double(nutrition[1])
        if protein == 0 { return 0 }
        return protein/total
    }
    
    private func getPercentFat() -> Double {
        let total = getTotal()
        let fat = Double(nutrition[2])
        if fat == 0 { return 0 }
        return fat/total
    }
    
    private func getPercentGreen() -> Double {
        let total = getTotal()
        let green = Double(nutrition[3])
        return green/total
    }
    
    private func isMuchCarbs() -> Bool {
        let carbsPercent = getPercentCarbs()
        return carbsPercent > 0.60
    }
    
    private func isLittleCarbs() -> Bool {
        let carbsPercent = getPercentCarbs()
        return carbsPercent < 0.20
    }
    
    private func isMuchProtein() -> Bool {
        let proteinPercent = getPercentProtein()
        return proteinPercent > 0.35
    }
    
    private func isLittleProtein() -> Bool {
        let proteinPercent = getPercentProtein()
        return proteinPercent < 0.10
    }
    
    private func isMuchFat() -> Bool {
        let fatPercent = getPercentFat()
        return fatPercent > 0.40
    }
    
    private func isLittleFat() -> Bool {
        let fatPercent = getPercentFat()
        return fatPercent < 0.04
    }
    
    private func isLittleGreen() -> Bool {
        let green = getPercentGreen()
        return green < 0.20
    }
    
}
