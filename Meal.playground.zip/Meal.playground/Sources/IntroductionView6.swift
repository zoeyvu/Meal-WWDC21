import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct IntroductionView6: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            VStack {
                HStack {
                    VStack {
                        Text("PROTEIN")
                            .textStyle(size: 27, color: protein , weight: .bold)
                        Spacer()
                            .frame(height: 10)
                        Text("Grow Muscle 💪🏽")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Produce Blood🩸")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Strong Bones🦴")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 10)
                        Text("🥩 🍗 🍖 🦀 🦞 🦑 🐙 🦐🐟.🌰 🥜 🥑 🍳 🥛 🧀 🐮 🐷 🐔 🐐 🦃 🦆")
                            .textStyle(size: 30, color: Color(.white) , weight: .regular)
                    }
                    .frame(width: 120)
                    Rectangle()
                        .fill(Color(#colorLiteral(red: 0.6679978967, green: 0.4751212597, blue: 0.2586010993, alpha: 1.0)))
                        .frame(width: 2, height: 360)
                    VStack {
                        Text("FAT")
                            .textStyle(size: 30, color: fat , weight: .bold)
                        Spacer()
                            .frame(height: 10)
                        Text("Hold Vitamins ❇️")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Store Energy ⚡")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Stay Focused 🤓")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 10)
                        Text("🌰 🥜 🥓 🍟 🥩 🍣 🍤 🍕 🍘 🥑 🫒 🦪 🧈 🥐 🥥 🧆 🍳 🥞 🍦 🧁 🍮")
                            .textStyle(size: 30, color: Color(.white) , weight: .regular)
                    }
                    .frame(width: 122)
                    Rectangle()
                        .fill(Color(#colorLiteral(red: 0.6679978967, green: 0.4751212597, blue: 0.2586010993, alpha: 1.0)))
                        .frame(width: 1, height: 360)
                    VStack {
                        Text("CARBS")
                            .textStyle(size: 30, color: carbs , weight: .bold)
                        Spacer()
                            .frame(height: 10)
                        Text("Fuel For Body ⛽")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Run The Brain 🧠")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 5)
                        Text("Heart Health ❤️")
                            .textStyle(size: 15, color: Color(.darkGray) , weight: .regular)
                        Spacer()
                            .frame(height: 10)
                        Text("🍠 🥔 🌾 🍟 🍕 🍞 🍛 🍙 🥨 🥟 🥐 🥖 🫓 🥯 🥪 🍚 🍜 🍥 🍩 🍪 🍘")
                            .textStyle(size: 30, color: Color(.white) , weight: .regular)
                    }
                    .frame(width: 120)
                }
            }
            .frame(height: 450)
            Text("There are 3 types of nutrient our body needs the most: Carbohydrates, Protein, and Fat. As you noticed, a dish can contain many type of nutrients.                                                             Example: 🍔 because it has protein and fat in 🥩, carbohydrates in 🍞, and 🥬 🍅 🧀")
                .textStyle(size: 15, color: Color(.darkGray), weight: .regular)
                .padding()
                .frame(width: 370, height: 130)
                .background(Color.white)
                .foregroundColor(.black)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray, lineWidth: 3)
                )
            Spacer()
                .frame(height: 15)
            Button(action: {
                AudioServicesPlaySystemSound(1107)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView7
                }
            }, label: {
                Text("Tap to continue")
                    .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
            })
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        .onTapGesture {
            AudioServicesPlaySystemSound(1107)
            // Go to next page
            DispatchQueue.main.asyncAfter(deadline: .now()) {
                PlaygroundPage.current.liveView = PlaygroundView.introductionView7
            }
        }
    }
}

