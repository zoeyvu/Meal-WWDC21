import SwiftUI

public struct PlaygroundView {
    
    // MARK: - Properties
    static var width: Double = 414
    static var height: Double = 900
    
}

// MARK: - Extensions
public extension PlaygroundView {
    static var preferedViewSize: CGSize {
        CGSize(width: width, height: height)
    }
    
    static var introductionView1: UIHostingController<IntroductionView1> {
        let view = UIHostingController(rootView: IntroductionView1())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView2: UIHostingController<IntroductionView2> {
        let view = UIHostingController(rootView: IntroductionView2())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView3: UIHostingController<IntroductionView3> {
        let view = UIHostingController(rootView: IntroductionView3())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView4: UIHostingController<IntroductionView4> {
        let view = UIHostingController(rootView: IntroductionView4())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView5: UIHostingController<IntroductionView5> {
        let view = UIHostingController(rootView: IntroductionView5())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView6: UIHostingController<IntroductionView6> {
        let view = UIHostingController(rootView: IntroductionView6())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView7: UIHostingController<IntroductionView7> {
        let view = UIHostingController(rootView: IntroductionView7())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView8: UIHostingController<IntroductionView8> {
        let view = UIHostingController(rootView: IntroductionView8())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var introductionView9: UIHostingController<IntroductionView9> {
        let view = UIHostingController(rootView: IntroductionView9())
        view.preferredContentSize = preferedViewSize
        return view
    }
    
    static var chooseFoodView: UIHostingController<ChooseFoodView> {
        let view = UIHostingController(rootView: ChooseFoodView(document: ChooseFoodDocument(), data: ChooseFoodData() ))
        view.preferredContentSize = preferedViewSize
        return view
    }
    

}

