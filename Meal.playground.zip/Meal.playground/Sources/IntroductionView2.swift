import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct IntroductionView2: View {
    // MARK: - Content View
    public var body: some View {
        VStack (alignment: .center) {
            Image(uiImage: #imageLiteral(resourceName: "2-2.png"))
                            .frame(height: 450)
                        Text("Hi amazing friend ✋                                                                 I am Zoey the fabulous nutritionist online 😎                                                                      There is an important question I have for you today: What is your body made from?")
                            .textStyle(size: 15, color: Color(.darkGray), weight: .regular)
                            .padding()
                            .frame(width: 370, height: 130)
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.gray, lineWidth: 3)
                            )
            Spacer()
                .frame(height: 15)
            Button(action: {
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()  + 0.2) {
                    AudioServicesPlaySystemSound(1026)
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView3
                }
            }, label: {
                Text("Tap to continue")
                    .textStyle(size: 10, color: Color(.darkGray), weight: .regular)
            })
        }
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
        .onTapGesture {
                AudioServicesPlaySystemSound(1026)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()  + 0.2) {
                    PlaygroundPage.current.liveView = PlaygroundView.introductionView3
                }
        }
    }
}

