import SwiftUI

    public var fat: Color {
        return Color(UIColor(red: 254/255, green: 215/255, blue: 102/255, alpha: 1.0))
    }

    public var protein: Color {
        return Color(UIColor(red: 254/255, green: 74/255, blue: 73/255, alpha: 1.0))
    }

    public var proteinLight: Color {
        return Color(UIColor(red: 254/255, green: 74/255, blue: 73/255, alpha: 7.0))
    }

    public var carbs: Color {
        return Color(UIColor(red: 50/255, green: 183/255, blue: 202/255, alpha: 1.0))
    }

    public var background: Color {
        return Color(UIColor(red: 244/255, green: 244/255, blue: 248/255, alpha: 1.0))
    }
