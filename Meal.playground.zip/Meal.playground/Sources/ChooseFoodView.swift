import SwiftUI
import AVFoundation
import PlaygroundSupport

public struct ChooseFoodView: View {
    // MARK: - Content View
    @ObservedObject var document: ChooseFoodDocument
    @ObservedObject var data: ChooseFoodData
    @State private var chosenPalette: String = ""
    @State private var currentNutrition = [0, 0, 0, 0]
    @State private var isDropped = false
    
    public var body: some View {
        VStack (alignment: .center) {
            
            PaletteChooser(document: document, chosenPalette: $chosenPalette)
                .frame(width: 420)
                .padding(.top)
            
            Spacer()
                .frame(height: 20)
            
            ScrollView(.horizontal, showsIndicators: true) {
                HStack {
                    ForEach(chosenPalette.map { String($0) }, id: \.self) {emoji in
                            Text(emoji)
                                .font(Font.system(size: 40))
                                .onDrag { return NSItemProvider(object: emoji as NSString) }
                    }
                }
            }
            .frame(height: 35)
            .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
            .onAppear{ self.chosenPalette = self.document.defaultPalette}

            
            GeometryReader { geometry in
                ZStack {
                    Color(#colorLiteral(red: 0.9686274529, green: 0.7116591147, blue: 0.4154293284, alpha: 0.4793891128)).overlay(
                        Group {
                            Image(uiImage: #imageLiteral(resourceName: "fork-and-knife.png"))
                        }
                    )
                    .onDrop(of: ["public.text"], isTargeted: nil) {
                        providers, location in
                        var location = geometry.convert(location, from: .global)
                        location = CGPoint(x: location.x - geometry.size.width/2, y: location.y - geometry.size.height/2)
                        return self.drop(providers: providers, at: location)
                    }
                    .cornerRadius(15)
                    
                    ForEach(self.document.emojis) { emoji in
                        Text(emoji.text)
                            .font(self.font(for: emoji))
                            .position(self.position(for: emoji, in: geometry.size))
                    }
                    
                    if !isDropped {
                        Text("Click and hold the food for 1s, then drag and drop it here")
                            .textStyle(size: 10, color: Color(#colorLiteral(red: 0.6514105994, green: 0.4758245303, blue: 0.2833955773, alpha: 1)), weight: .bold)
                            .position(CGPoint(x: geometry.size.width/2 - 10, y: 40))
                    }
                }
                .padding()
            }
            
//            HStack {
//                Text("C: \(currentNutrition[0])")
//                Text("P: \(currentNutrition[1])")
//                Text("F: \(currentNutrition[2])")
//                Text("V: \(currentNutrition[3])")
//            }
            
            Button(action: {
                AudioServicesPlaySystemSound(1326)
                // Go to next page
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    PlaygroundPage.current.setLiveView(ResultView(nutrition: $currentNutrition))
                }
            }, label: {
                Text("CHECK RESULT")
                    .textStyle(size: 35, color: Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)), weight: .bold)
                    .frame(width: 380, height: 60)
                    //.background(Color(#colorLiteral(red: 0.9960784314, green: 0.3445431901, blue: 0.2862745098, alpha: 0.9191429501)))
                    .background(Color(#colorLiteral(red: 0.9686274529, green: 0.7116591147, blue: 0.4154293284, alpha: 1)))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.vertical)
            })
            Spacer()
                .frame(height: 20)
            
            
        }
        .padding()
        .frame(width: 414, height: 700)
        .background(Color(#colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)))
    }

    private func font(for emoji: ChooseFood.Emoji) -> Font {
        Font.system(size: emoji.fontSize)
    }
    
    private func position(for emoji: ChooseFood.Emoji, in size: CGSize) -> CGPoint {
        CGPoint(x: emoji.location.x + size.width/2, y: emoji.location.y + size.height/2)
    }
    
    private func drop(providers: [NSItemProvider], at location: CGPoint) -> Bool {
        let found = providers.loadObjects(ofType: String.self) { string in
            self.document.addEmoji(string, at: location, size: 85)
            if let addingNutrition = data.lookup[string] {
                currentNutrition[0] += addingNutrition[0]
                currentNutrition[1] += addingNutrition[1]
                currentNutrition[2] += addingNutrition[2]
                currentNutrition[3] += addingNutrition[3]
            }
        }
        
        isDropped = true

        return found
        
    }
    
}




